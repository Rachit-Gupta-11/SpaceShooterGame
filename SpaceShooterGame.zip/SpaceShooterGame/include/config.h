#ifndef CONFIG_H
#define CONFIG_H

const int SCREEN_WIDTH = 70;
const int SCREEN_HEIGHT = 20;

#endif 